import { S3Client, ListObjectsV2Command, CopyObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { Upload } from '@aws-sdk/lib-storage';
import fs from 'fs';
import path from 'path';
import { globby } from 'globby';
import dotenv from 'dotenv';

// Load secrets from .env.build
dotenv.config({ path: '.env.build' });

// Load environment-specific vars if mode is provided
const mode = process.env.NODE_ENV || 'staging';
dotenv.config({ path: `.env.${mode}`, override: true });

const bucketFolder = mode === 'production' ? 'watchtower-production' : 'watchtower-staging';

const {
    AWS_S3_BASE_URL,
    AWS_BUCKET_NAME,
    AWS_REGION,
    AWS_ACCESS_KEY,
    AWS_ACCESS_SECRET,
    API_BASE_URL
} = process.env;

if (!AWS_S3_BASE_URL || !AWS_BUCKET_NAME || !AWS_ACCESS_KEY || !AWS_ACCESS_SECRET) {
    console.error("❌ ERR: Missing required environment variables in .env.build");
    process.exit(1);
}

const s3Client = new S3Client({
    endpoint: AWS_S3_BASE_URL,
    credentials: {
        accessKeyId: AWS_ACCESS_KEY,
        secretAccessKey: AWS_ACCESS_SECRET,
    },
    region: AWS_REGION || 'us-east-1',
    forcePathStyle: true,
});

async function getCurrentVersion() {
    if (!API_BASE_URL) return null;
    try {
        const res = await fetch(`${API_BASE_URL}/meta/version`);
        if (!res.ok) return null;
        const data = await res.json();
        return data.version || data;
    } catch (e) {
        console.error("⚠️ Failed to fetch current version:", e.message);
        return null;
    }
}

async function archiveLatest(version) {
    if (!version) return;
    console.log(`📦 Archiving 'latest' release to version: ${version}...`);

    const prefix = `${bucketFolder}/latest/`;
    const targetPrefix = `${bucketFolder}/${version}/`;

    try {
        // 1. List all objects under latest/
        const listCmd = new ListObjectsV2Command({
            Bucket: AWS_BUCKET_NAME,
            Prefix: prefix,
        });
        const listResponse = await s3Client.send(listCmd);

        if (!listResponse.Contents || listResponse.Contents.length === 0) {
            console.log("ℹ️  'latest' folder is empty or does not exist. Skipping archive.");
            return;
        }

        // 2. Copy and Delete each object
        for (const obj of listResponse.Contents) {
            const oldKey = obj.Key;
            const newKey = oldKey.replace(prefix, targetPrefix);

            console.log(`  ➡️  Moving ${oldKey} to ${newKey}`);

            // Copy
            await s3Client.send(new CopyObjectCommand({
                Bucket: AWS_BUCKET_NAME,
                CopySource: `${AWS_BUCKET_NAME}/${oldKey}`,
                Key: newKey,
            }));

            // Delete
            await s3Client.send(new DeleteObjectCommand({
                Bucket: AWS_BUCKET_NAME,
                Key: oldKey,
            }));
        }
        console.log("✅ DONE: Archive complete.");
    } catch (err) {
        console.error(`❌ ERR: Failed to archive latest: ${err.message}`);
        // We don't exit(1) here to allow the new release to potentially proceed, 
        // but log clearly it failed.
    }
}

async function updateLocalVersion(newVersion) {
    const pkgPath = path.resolve('package.json');
    const tauriConfigPath = path.resolve('src-tauri/tauri.conf.json');

    if (fs.existsSync(pkgPath)) {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
        pkg.version = newVersion;
        fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');
        console.log(`📝 Updated package.json version to ${newVersion}`);
    }

    if (fs.existsSync(tauriConfigPath)) {
        const tauriConfig = JSON.parse(fs.readFileSync(tauriConfigPath, 'utf8'));
        tauriConfig.version = newVersion;
        fs.writeFileSync(tauriConfigPath, JSON.stringify(tauriConfig, null, 2) + '\n');
        console.log(`📝 Updated tauri.conf.json version to ${newVersion}`);
    }
}

async function handleVersioning(incrementType) {
    if (!API_BASE_URL) {
        console.warn("⚠️  WARN: API_BASE_URL not set, skipping remote versioning.");
        return null;
    }

    if (!['major', 'minor', 'patch'].includes(incrementType)) {
        console.log(`ℹ️  No valid increment type (${incrementType}), skipping version sync.`);
        return null;
    }

    console.log(`🔄 Incrementing version (${incrementType}) on server...`);
    try {
        // 1. Increment on server
        const incRes = await fetch(`${API_BASE_URL}/meta/version/increment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: incrementType })
        });

        if (!incRes.ok) {
            const errText = await incRes.text();
            throw new Error(`Failed to increment: ${incRes.status} ${errText}`);
        }

        // 2. Fetch latest version
        const verRes = await fetch(`${API_BASE_URL}/meta/version`);
        if (!verRes.ok) throw new Error("Failed to fetch latest version");

        const data = await verRes.json();
        const newVersion = data.version || data; // Handle both {version: "1.0.0"} or just "1.0.0"

        console.log(`✅ Server version is now: ${newVersion}`);

        // 3. Update local files
        await updateLocalVersion(newVersion);
        return newVersion;
    } catch (err) {
        console.error(`❌ ERR: Versioning failed: ${err.message}`);
        // We continue with upload even if versioning fails, or move to exit(1) if critical
        return null;
    }
}

async function updateRemoteUpdateJson(updaterExt, newVersion, signature, contentLength = 0) {
    if (!newVersion) newVersion = "1.0.0";

    const isMac = process.platform === 'darwin';
    const isWin = process.platform === 'win32';
    const isLinux = process.platform === 'linux';

    let platforms = {};
    if (isMac) {
        platforms = {
            "darwin-aarch64": {
                signature: signature,
                url: `${AWS_S3_BASE_URL}/${AWS_BUCKET_NAME}/${bucketFolder}/latest/Watchtower-desktop.${updaterExt}`,
                content_length: contentLength
            },
            "darwin-x86_64": {
                signature: signature,
                url: `${AWS_S3_BASE_URL}/${AWS_BUCKET_NAME}/${bucketFolder}/latest/Watchtower-desktop.${updaterExt}`,
                content_length: contentLength
            }
        };
    } else if (isWin) {
        const platformArch = process.arch === 'arm64' ? 'windows-aarch64' : 'windows-x86_64';
        platforms = {
            [platformArch]: {
                signature: signature,
                url: `${AWS_S3_BASE_URL}/${AWS_BUCKET_NAME}/${bucketFolder}/latest/Watchtower-desktop.${updaterExt}`,
                content_length: contentLength
            }
        };
    } else if (isLinux) {
        const platformArch = process.arch === 'arm64' ? 'linux-aarch64' : 'linux-x86_64';
        platforms = {
            [platformArch]: {
                signature: signature,
                url: `${AWS_S3_BASE_URL}/${AWS_BUCKET_NAME}/${bucketFolder}/latest/Watchtower-desktop.${updaterExt}`,
                content_length: contentLength
            }
        };
    }

    const updateJson = {
        version: newVersion,
        notes: `Released on ${new Date().toISOString()}`,
        pub_date: new Date().toISOString(),
        platforms: platforms
    };

    const upload = new Upload({
        client: s3Client,
        params: {
            Bucket: AWS_BUCKET_NAME,
            Key: `${bucketFolder}/latest/update.json`,
            Body: JSON.stringify(updateJson, null, 2),
            ContentType: 'application/json',
            ACL: "public-read",
        },
    });
    await upload.done();
    console.log("✅ Updated update.json with new signature.");
}

async function uploadFile() {
    // Check for increment type in arguments, default to 'patch'
    const incrementType = process.argv[2] || 'patch';

    // ARCHIVE LATEST IF MAJOR
    if (incrementType.toLowerCase() === 'major') {
        const currentVersion = await getCurrentVersion();
        if (currentVersion) {
            await archiveLatest(currentVersion);
        } else {
            console.warn("⚠️  Could not determine current version. Skipping archive.");
        }
    }

    const isMac = process.platform === 'darwin';
    const isWin = process.platform === 'win32';
    const isLinux = process.platform === 'linux';

    const patterns = isMac
        ? ['src-tauri/target/release/bundle/dmg/*.dmg', 'src-tauri/target/release/bundle/macos/*.tar.gz', 'src-tauri/target/release/bundle/**/*.sig']
        : isWin
            ? ['src-tauri/target/release/bundle/nsis/*.exe', 'src-tauri/target/release/bundle/msi/*.msi', 'src-tauri/target/release/bundle/msi/*.msi.zip', 'src-tauri/target/release/bundle/**/*.sig']
            : isLinux
                ? ['src-tauri/target/release/bundle/appimage/*.AppImage', 'src-tauri/target/release/bundle/deb/*.deb', 'src-tauri/target/release/bundle/rpm/*.rpm', 'src-tauri/target/release/bundle/**/*.sig']
                : [];

    const files = await globby(patterns);
    const artifactFiles = files.filter(f => !f.endsWith('.sig'));
    const sigFiles = files.filter(f => f.endsWith('.sig'));

    if (artifactFiles.length === 0) {
        console.error(`❌ ERR: No build artifact found matching: ${patterns[0]}`);
        process.exit(1);
    }

    let signature = "";
    if (sigFiles.length > 0) {
        const updaterSig = sigFiles.find(s => s.endsWith('.tar.gz.sig') || s.endsWith('.msi.zip.sig') || s.endsWith('.AppImage.sig')) || sigFiles[0];
        signature = fs.readFileSync(updaterSig, 'utf8').trim();
        console.log(`🔑 Found signature file: ${updaterSig}`);
    } else {
        console.log("⚠️ No signature (.sig) file found. Tauri updater may not work. Please ensure TAURI_SIGNING_PRIVATE_KEY is set.");
    }

    try {
        for (const filePath of artifactFiles) {
            const fileExtension = filePath.endsWith('.tar.gz') ? 'tar.gz' : (filePath.endsWith('.msi.zip') ? 'msi.zip' : path.extname(filePath).slice(1).toLowerCase());
            const targetKey = `${bucketFolder}/latest/Watchtower-desktop.${fileExtension}`;

            console.log(`🚀 Uploading ${filePath} to...`);
            console.log(`🔗 s3://${AWS_BUCKET_NAME}/${targetKey}`);

            const fileStream = fs.createReadStream(filePath);
            let contentType = 'application/octet-stream';
            if (fileExtension === 'dmg') contentType = 'application/x-apple-diskimage';
            if (fileExtension === 'tar.gz') contentType = 'application/gzip';
            if (fileExtension === 'zip' || fileExtension === 'msi.zip') contentType = 'application/zip';
            if (fileExtension === 'appimage') contentType = 'application/x-executable';
            if (fileExtension === 'deb') contentType = 'application/vnd.debian.binary-package';

            const parallelUploads3 = new Upload({
                client: s3Client,
                params: {
                    Bucket: AWS_BUCKET_NAME,
                    Key: targetKey,
                    Body: fileStream,
                    ContentType: contentType,
                    ACL: 'public-read',
                },
            });

            parallelUploads3.on("httpUploadProgress", (progress) => {
                if (progress.total) {
                    process.stdout.write(`\r📤 Progress: ${Math.round((progress.loaded / progress.total) * 100)}%`);
                }
            });

            await parallelUploads3.done();
            process.stdout.write('\n');
            console.log(`✅ DONE: Successfully uploaded ${fileExtension} artifact.`);
        }

        let updaterExt = isMac ? 'tar.gz' : (isWin ? 'msi' : 'AppImage');
        if (artifactFiles.some(f => f.endsWith('.msi.zip'))) updaterExt = 'msi.zip';

        // HANDLE VERSIONING AFTER UPLOAD
        let newVersion = await handleVersioning(incrementType.toLowerCase());

        if (!newVersion) {
            const pkgPath = path.resolve('package.json');
            if (fs.existsSync(pkgPath)) {
                newVersion = JSON.parse(fs.readFileSync(pkgPath, 'utf8')).version;
            } else {
                newVersion = "0.0.0";
            }
        }

        if (signature) {
            const updaterFile = artifactFiles.find(f => f.endsWith(`.${updaterExt}`));
            const contentLength = updaterFile ? fs.statSync(updaterFile).size : 0;
            await updateRemoteUpdateJson(updaterExt, newVersion, signature, contentLength);
        }
    } catch (err) {
        console.error("\n❌ ERR: Upload failed:", err.message);
        process.exit(1);
    }
}

uploadFile();
